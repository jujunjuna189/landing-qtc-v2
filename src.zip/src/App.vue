<script setup lang="ts">
import { useAnalytics } from './composable/use-analytics';


useAnalytics()
</script>

<template>
  <router-view />
</template>

<style scoped></style>
