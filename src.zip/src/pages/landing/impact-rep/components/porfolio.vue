<template>
    <div class="grid grid-cols-1 lg:grid-cols-3">
        <div class="border border-primary-dark flex justify-center items-center py-24">
            <span class="text-4xl text-primary-dark font-semibold">
                Image
            </span>
        </div>
        <div class="border border-primary-dark flex justify-center items-center py-24">
            <span class="text-4xl text-primary-dark font-semibold">
                Image
            </span>
        </div>
        <div class="border border-primary-dark flex justify-center items-center py-24">
            <span class="text-4xl text-primary-dark font-semibold">
                Image
            </span>
        </div>
    </div>
</template>